Algorithmic Botany workshop, Berlin 29.01.2018
