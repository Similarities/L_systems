var angle=1.57;
var axiom="-F"; // call by name
//var axiom = "X";
var sentence = axiom;
var len = 25;
var limit =6;
var dec_percent=0.6;
var angle2= 2;

var rules = []; // array ! lenguage 
//rules[0]={a: "F",b: "FF-[-F+F+F]+[+F-F-F]"};

rules[0]={a: "F",b: "F+F-F-F+F"};
//b: "F[+F]F[-F]F"};
//rules[0]={a: "X",b: "F[+X]F[-X]+X"};

/*rules[1]={
    a:"F",
    b:"FF+["
};*/


function generate(){
    // takes axiom and apply rules
    if (limit == 0){return;}
    len*=0.6;
    var nextSentence=""; // empty
    for (var i=0; i < sentence.length; i++){
        var current = sentence.charAt(i);
        var found = false;
        for (var j = 0; j< rules.length; j++){

            if (current == rules[j].a){
                // bedingung: wenn in array [j] = a
                found = true;
                nextSentence += rules[j].b;
                break;

            }

        }
        if (!found){
            nextSentence += current; // geht eine Position weiter.
        }
        

    }

    sentence = nextSentence;
    createP(sentence);
    turtle(); // again?
    limit-= 1;



}
function turtle(){
	background(230,150,110);
    //background(51);
    //resetMatrix(); // forget rotation etc. 
    translate(width/2,height/2);
    var a=0;
    a=sin(random(0,1));

   // stroke(255,100,100);// line with color
    // read string - interpret calculate
    //sentence = F+-[]
    for(var i =0; i<sentence.length; i++){
        // iterate until sentence length is reached
        var current = sentence.charAt(i); // please  bring me to current letter in string
        if (current == "F"){
            line(0,0,0,len*2);
			stroke(255,100,100/a);
			//transform:scale(5/i)
            translate(0,-len); // move to end of line



        }
        else if ( current == "+"){
            rotate(angle);

			//line(0,0,0,len);
            //stroke(255,100,50/a);// line with color

        }
        else if ( current == "-"){
            rotate(-angle);
			//line(0,0,0,len);
            //stroke(255,100/a,len);// line with color
            
        }
        else if ( current == "["){
            push(); // remember position
           // stroke(255,100,50/a);// line with color
            
        }
        else if ( current == "]"){
            pop(); // go to remembered position
            
        }
        /*else if ( current == "X"){
            
            angle2 = angle/2;
            rotate(angle2); // go to remembered position
            
        }*/


    }


}
function setup()
{
    createCanvas(900,650);
	turtle();
	generate();
	generate();
	generate();
	generate();


    //angle=radians(22.5);
   // createP(axiom);// create Paragraph - print it
   // turtle(); // curso - draws line e.g.

   // var button = createButton("generate"); // text on Button
   // button.mousePressed(generate);



}

function draw(){

turtle();
generate();


for (i=0; i<100; i++){
translate(-len,0,0,-len);
turtle();
rotate(0.7);

}}




