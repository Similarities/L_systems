
const PI=3.1415926;
var angle = 0;
var decreased_percent= 0.7;
var branchLength=150; // length - but as well recursion depth
var slider;



function setup(){
    createCanvas (800,650);
    slider=createSlider(0,PI*2,0.3,0.1);
    // sin(millis()*0.0001)


}

function draw () {
    background(50); // grey
    stroke(255,90,90); // white
    translate(width/2,height); // understands without definition?
    angle=slider.value()*sin(millis()*0.0001);

    // recursion - function that calls 

branch(branchLength);
    
    
}

function branch(len)
{   strokeWeight(len/11);
    var hue= map(len,0,branchLength,0,255);
    stroke(hue,255,255)
    //line(0,0,0,-len+0.2*random(0,branchLength));
    line(0,0,0,-len);
    translate(0, -len);
    var n=1;
    if (len>7){
        // coo-system
        push();
        n=n+5;
        //rotate(angle-random(0,2));
        rotate(angle-angle/2);
        branch(len*decreased_percent); // recursion stops for decreasing lenght.
        pop();

        // repeat for other angle direction.
        push();
        rotate(-angle);
        // add wind with random
        branch(len*decreased_percent); // recursion stops for decreasing lenght.
        pop();
    }

}

