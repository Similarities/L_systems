var max_number_of_points=3000;
var n=0;
var c=3;

function setup ()
{
    createCanvas(800,800);
    colorMode(HSB);
    angleMode(DEGREES);
    background (255,104,100);
    
    /* 
    RGB red green blue
    HSB Hue, satur, bright
    */
        
}
function draw ()
{
    translate (width/2, height/2);
    for (var i =0; i <n; i++)
    {
        
        //ellipse(random(50,800), (n-i),random(0,300), random(0,300));
        var a= i*137.7;
        //var r=random(20,200);
        var r=c*sqrt(i);
        var x = r*cos(a);
        var y = r*sin(a);
        //strokeWeight(1);
        //stroke(50, 204, 200);
        ellipse(x,y, 4,4);
        fill(0, 190, 90);
        noStroke();
       

    }
    if (i<max_number_of_points)
    {
        n+=5;
    }

    


}